package com.mansoor.emsystem.projection;

public interface DepartmentProjection {
    Long getId();
    String getName();
}
