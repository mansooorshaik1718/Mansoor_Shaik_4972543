package com.mansoor.emsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmsystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
